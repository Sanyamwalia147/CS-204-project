export PIN_ROOT=/your/pin/directory/
mkdir -p obj-intel64
make obj-intel64/champsim_tracer.so
